package com.example.yukhnovets_shop.presenter

import com.example.yukhnovets_shop.domain.model.Product
import moxy.MvpView
import moxy.viewstate.strategy.AddToEndSingleStrategy
import moxy.viewstate.strategy.StateStrategyType

@StateStrategyType(AddToEndSingleStrategy::class)
interface BasketView : MvpView {
    fun setItems(products: List<Product>)
    fun removeItem(position: Int)
}