package com.example.yukhnovets_shop.domain

interface ViewedProductDao {
    fun addProduct(productId: Long)
    fun getAllProducts(): List<Long>
}
