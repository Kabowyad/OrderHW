package com.example.yukhnovets_shop.domain.model

enum class Payment {
    CARD, CASH
}
